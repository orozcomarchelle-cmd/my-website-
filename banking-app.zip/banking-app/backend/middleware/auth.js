// middleware/auth.js
//
// HOW TO SECURE ROUTES (the short version):
// 1. Every route that touches user data must run behind middleware
//    that verifies a valid, unexpired JWT (or session cookie) BEFORE
//    the route handler runs.
// 2. Never trust an ID that comes from the client (e.g. req.body.userId)
//    to decide whose data to return — always derive "who is this?"
//    from the verified token, and use that for all lookups.
// 3. Keep the JWT secret in an environment variable, never hard-coded
//    or committed to source control.

import jwt from "jsonwebtoken";

const JWT_SECRET = process.env.JWT_SECRET || "dev-only-secret-change-me";

export function requireAuth(req, res, next) {
  // We read the token from an httpOnly cookie rather than a header/
  // localStorage where possible — httpOnly cookies can't be read by
  // client-side JS, which blocks a whole class of XSS token-theft
  // attacks. We also accept an Authorization header as a fallback so
  // the same middleware works for pure API clients.
  const bearer = req.headers.authorization?.startsWith("Bearer ")
    ? req.headers.authorization.slice(7)
    : null;
  const token = req.cookies?.token || bearer;

  if (!token) {
    return res.status(401).json({ error: "Not authenticated." });
  }

  try {
    const payload = jwt.verify(token, JWT_SECRET); // throws if invalid/expired
    req.userId = payload.sub; // attach verified identity to the request
    next();
  } catch (err) {
    return res.status(401).json({ error: "Invalid or expired session." });
  }
}

export { JWT_SECRET };
