// routes/account.js
import express from "express";
import { body, validationResult } from "express-validator";
import { requireAuth } from "../middleware/auth.js";
import { db, findUserById } from "../data/store.js";

const router = express.Router();

// requireAuth runs on every route below — no route handler executes
// for an unauthenticated request. This is the pattern to follow for
// any endpoint touching account data, admin actions, etc.
router.use(requireAuth);

// GET /api/account/me — balance + profile for the CURRENTLY LOGGED IN user.
// Notice we use req.userId (set by requireAuth from the verified token),
// never an id passed in the query string or body. If a client could
// pass ?userId=someone-else, that would be a broken access control bug
// (an "IDOR" — Insecure Direct Object Reference).
router.get("/me", (req, res) => {
  const user = findUserById(req.userId);
  if (!user) return res.status(404).json({ error: "User not found." });
  res.json({ id: user.id, name: user.name, email: user.email, balance: user.balance });
});

// GET /api/account/transactions — recent transactions for the logged-in user only.
router.get("/transactions", (req, res) => {
  const userTx = db.transactions
    .filter((t) => t.userId === req.userId)
    .sort((a, b) => new Date(b.date) - new Date(a.date));
  res.json(userTx);
});

// POST /api/account/transfer — move funds from the logged-in user to
// a recipient identified by email.
router.post(
  "/transfer",
  [
    // Validate shape and range server-side. Client-side validation is
    // only a UX nicety — a malicious or buggy client can always send
    // whatever it wants directly to the API, so the server must
    // re-check everything.
    body("recipientEmail").isEmail().withMessage("Valid recipient email required.").normalizeEmail(),
    body("amount")
      .isFloat({ gt: 0 })
      .withMessage("Amount must be a positive number.")
      .toFloat(),
    // Free-text memo: cap length and strip control characters to
    // avoid storing/echoing back unexpectedly large or malformed
    // strings. If this were ever rendered as raw HTML on a page,
    // it would also need output-encoding/escaping to prevent
    // stored XSS — React does this automatically when you render
    // text via {value}, but avoid dangerouslySetInnerHTML with it.
    body("memo").optional().isString().trim().isLength({ max: 140 }),
  ],
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ error: errors.array()[0].msg });
    }

    const sender = findUserById(req.userId);
    const { recipientEmail, amount, memo } = req.body;
    const recipient = db.users.find((u) => u.email.toLowerCase() === recipientEmail.toLowerCase());

    if (!recipient) return res.status(404).json({ error: "Recipient not found." });
    if (recipient.id === sender.id) return res.status(400).json({ error: "Cannot transfer to yourself." });
    if (amount > sender.balance) return res.status(400).json({ error: "Insufficient funds." });

    // In a real system this whole block would be a single atomic
    // database transaction (e.g. SQL BEGIN/COMMIT, or a Mongo
    // session transaction) so a crash mid-transfer can never leave
    // money debited from one account without crediting the other.
    sender.balance = +(sender.balance - amount).toFixed(2);
    recipient.balance = +(recipient.balance + amount).toFixed(2);

    const now = new Date().toISOString().slice(0, 10);
    db.transactions.push({
      id: `t${db.transactions.length + 1}`,
      userId: sender.id,
      type: "debit",
      amount,
      description: memo ? `Transfer to ${recipient.name}: ${memo}` : `Transfer to ${recipient.name}`,
      date: now,
    });
    db.transactions.push({
      id: `t${db.transactions.length + 1}`,
      userId: recipient.id,
      type: "credit",
      amount,
      description: memo ? `Transfer from ${sender.name}: ${memo}` : `Transfer from ${sender.name}`,
      date: now,
    });

    res.json({ ok: true, newBalance: sender.balance });
  }
);

export default router;
