// routes/auth.js
import express from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { body, validationResult } from "express-validator";
import rateLimit from "express-rate-limit";
import { findUserByEmail } from "../data/store.js";
import { JWT_SECRET } from "../middleware/auth.js";

const router = express.Router();

// Brute-force protection: limit login attempts per IP. Without this,
// an attacker can script thousands of password guesses per minute.
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 10, // 10 attempts per window per IP
  message: { error: "Too many login attempts. Please try again later." },
  standardHeaders: true,
  legacyHeaders: false,
});

// INPUT VALIDATION:
// - express-validator declaratively checks shape/type/format BEFORE
//   any of this data touches business logic.
// - .isEmail() / .normalizeEmail() reject malformed input and reduce
//   the search space for injection-style payloads.
// - We never trust req.body directly — always read from the
//   validated/sanitized result.
router.post(
  "/login",
  loginLimiter,
  [
    body("email").isEmail().withMessage("Valid email required.").normalizeEmail(),
    body("password").isString().isLength({ min: 8 }).withMessage("Password must be at least 8 characters."),
  ],
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ error: errors.array()[0].msg });
    }

    const { email, password } = req.body;
    const user = findUserByEmail(email);

    // Deliberately vague error message — "user not found" vs "wrong
    // password" tells an attacker which half of the credentials was
    // right. Always return one generic message for both cases.
    const invalidMsg = "Invalid email or password.";
    if (!user) return res.status(401).json({ error: invalidMsg });

    const passwordMatches = bcrypt.compareSync(password, user.passwordHash);
    if (!passwordMatches) return res.status(401).json({ error: invalidMsg });

    // Sign a short-lived token. Short expiry limits the damage window
    // if a token is ever stolen.
    const token = jwt.sign({ sub: user.id }, JWT_SECRET, { expiresIn: "1h" });

    // httpOnly: JS on the page can't read this cookie (mitigates XSS).
    // secure: only sent over HTTPS in production.
    // sameSite: 'strict' or 'lax' mitigates CSRF by refusing to send
    // the cookie on cross-site requests.
    res.cookie("token", token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 60 * 60 * 1000,
    });

    res.json({
      token, // also returned in-body for demo clients using localStorage/Bearer auth
      user: { id: user.id, name: user.name, email: user.email },
    });
  }
);

router.post("/logout", (req, res) => {
  res.clearCookie("token");
  res.json({ ok: true });
});

export default router;
