// data/store.js
//
// This is an in-memory "database" so the demo runs with zero setup.
// In a real app, swap this out for Postgres/MySQL/Mongo etc., and
// ALWAYS use parameterized queries / an ORM's query builder — never
// build SQL strings by concatenating user input (that's how SQL
// injection happens).

import bcrypt from "bcryptjs";

// Passwords are hashed even in this mock store — never store plaintext
// passwords anywhere, not even in a demo, so the habit sticks.
const users = [
  {
    id: "u1",
    email: "jane@example.com",
    // password: "Password123!"
    passwordHash: bcrypt.hashSync("Password123!", 10),
    name: "Jane Doe",
    balance: 4231.55,
  },
  {
    id: "u2",
    email: "sam@example.com",
    // password: "Password123!"
    passwordHash: bcrypt.hashSync("Password123!", 10),
    name: "Sam Lee",
    balance: 980.0,
  },
];

const transactions = [
  { id: "t1", userId: "u1", type: "debit", amount: 42.1, description: "Coffee Shop", date: "2026-07-20" },
  { id: "t2", userId: "u1", type: "credit", amount: 1500.0, description: "Payroll Deposit", date: "2026-07-18" },
  { id: "t3", userId: "u1", type: "debit", amount: 89.99, description: "Electric Bill", date: "2026-07-15" },
  { id: "t4", userId: "u2", type: "credit", amount: 200.0, description: "Refund", date: "2026-07-19" },
];

export const db = { users, transactions };

export function findUserByEmail(email) {
  return users.find((u) => u.email.toLowerCase() === email.toLowerCase());
}

export function findUserById(id) {
  return users.find((u) => u.id === id);
}
