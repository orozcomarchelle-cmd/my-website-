// server.js
import express from "express";
import cors from "cors";
import helmet from "helmet";
import cookieParser from "cookie-parser";
import rateLimit from "express-rate-limit";
import dotenv from "dotenv";

import authRoutes from "./routes/auth.js";
import accountRoutes from "./routes/account.js";

dotenv.config();

const app = express();

// --- Security middleware (applies to EVERY request) ---
// helmet() sets a batch of protective HTTP headers (e.g. disables
// sniffing, sets a baseline Content-Security-Policy, hides
// X-Powered-By) — a cheap first line of defense.
app.use(helmet());

// CORS: only allow the known frontend origin to make credentialed
// requests. Leaving this wide open (origin: "*") together with
// credentials would let any website read a logged-in user's data.
app.use(
  cors({
    origin: process.env.FRONTEND_URL || "http://localhost:5173",
    credentials: true,
  })
);

// Body size limit prevents someone from sending a huge payload to
// exhaust server memory (a simple denial-of-service vector).
app.use(express.json({ limit: "10kb" }));
app.use(cookieParser());

// Global rate limiting as a second layer on top of the login-specific
// limiter in routes/auth.js — slows down scripted abuse across the
// whole API, not just login.
app.use(
  rateLimit({
    windowMs: 60 * 1000,
    max: 100, // 100 requests/minute/IP across the API
  })
);

app.use("/api/auth", authRoutes);
app.use("/api/account", accountRoutes);

app.get("/api/health", (req, res) => res.json({ ok: true }));

// Generic error handler: never leak stack traces or internal error
// details to the client in production — log them server-side instead.
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: "Something went wrong." });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`API listening on http://localhost:${PORT}`));
