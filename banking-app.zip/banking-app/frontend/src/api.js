// api.js
//
// Central place for talking to the backend. Using `credentials:
// "include"` sends the httpOnly auth cookie automatically — the
// frontend JS never needs to see or handle the token directly, which
// is the safer pattern versus storing it in localStorage.

const BASE_URL = import.meta.env.VITE_API_URL || "http://localhost:4000/api";

async function request(path, { method = "GET", body } = {}) {
  const res = await fetch(`${BASE_URL}${path}`, {
    method,
    headers: { "Content-Type": "application/json" },
    credentials: "include",
    body: body ? JSON.stringify(body) : undefined,
  });

  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    // Surface the server's error message but never assume it's safe
    // to render as HTML — React text interpolation escapes it for us.
    throw new Error(data.error || "Request failed.");
  }
  return data;
}

export const api = {
  login: (email, password) => request("/auth/login", { method: "POST", body: { email, password } }),
  logout: () => request("/auth/logout", { method: "POST" }),
  getMe: () => request("/account/me"),
  getTransactions: () => request("/account/transactions"),
  transfer: (recipientEmail, amount, memo) =>
    request("/account/transfer", { method: "POST", body: { recipientEmail, amount, memo } }),
};
