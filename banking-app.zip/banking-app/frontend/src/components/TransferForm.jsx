import { useState } from "react";
import { api } from "../api.js";

export default function TransferForm({ onSuccess }) {
  const [recipientEmail, setRecipientEmail] = useState("");
  const [amount, setAmount] = useState("");
  const [memo, setMemo] = useState("");
  const [status, setStatus] = useState({ type: "", message: "" });
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setStatus({ type: "", message: "" });

    // Basic client-side sanity checks for a fast, friendly UX. These
    // are NOT the security boundary — the server re-validates
    // everything independently in routes/account.js, since a client
    // can always bypass frontend JS entirely.
    const numericAmount = Number(amount);
    if (!recipientEmail || !numericAmount || numericAmount <= 0) {
      setStatus({ type: "error", message: "Enter a valid recipient and amount." });
      return;
    }

    setSubmitting(true);
    try {
      const result = await api.transfer(recipientEmail.trim(), numericAmount, memo.trim());
      setStatus({ type: "success", message: `Transfer complete. New balance: $${result.newBalance.toFixed(2)}` });
      setRecipientEmail("");
      setAmount("");
      setMemo("");
      onSuccess?.();
    } catch (err) {
      setStatus({ type: "error", message: err.message });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-slate-700 mb-1">Recipient email</label>
        <input
          type="email"
          required
          value={recipientEmail}
          onChange={(e) => setRecipientEmail(e.target.value)}
          className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
          placeholder="sam@example.com"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-slate-700 mb-1">Amount (USD)</label>
        <input
          type="number"
          required
          min="0.01"
          step="0.01"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
          placeholder="100.00"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-slate-700 mb-1">Memo (optional)</label>
        <input
          type="text"
          maxLength={140}
          value={memo}
          onChange={(e) => setMemo(e.target.value)}
          className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
          placeholder="Rent, dinner, etc."
        />
      </div>

      {status.message && (
        <p
          className={`text-sm rounded-md px-3 py-2 border ${
            status.type === "error"
              ? "text-red-600 bg-red-50 border-red-200"
              : "text-green-700 bg-green-50 border-green-200"
          }`}
        >
          {status.message}
        </p>
      )}

      <button
        type="submit"
        disabled={submitting}
        className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:opacity-60 text-white font-medium rounded-lg py-2 text-sm transition"
      >
        {submitting ? "Sending…" : "Send transfer"}
      </button>
    </form>
  );
}
