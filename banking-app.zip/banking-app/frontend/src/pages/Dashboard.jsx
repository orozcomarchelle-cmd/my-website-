import { useEffect, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../api.js";
import TransferForm from "../components/TransferForm.jsx";

export default function Dashboard({ user, onLoggedOut }) {
  const [account, setAccount] = useState(null);
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const loadData = useCallback(async () => {
    try {
      const [me, tx] = await Promise.all([api.getMe(), api.getTransactions()]);
      setAccount(me);
      setTransactions(tx);
    } catch (err) {
      // A 401 here typically means the session expired — send the
      // user back to login rather than showing a broken dashboard.
      setError(err.message);
      navigate("/login");
    } finally {
      setLoading(false);
    }
  }, [navigate]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  async function handleLogout() {
    await api.logout();
    onLoggedOut();
    navigate("/login");
  }

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center text-slate-500">Loading…</div>;
  }

  return (
    <div className="min-h-screen bg-slate-100">
      <header className="bg-white border-b border-slate-200">
        <div className="max-w-5xl mx-auto px-4 py-4 flex items-center justify-between">
          <h1 className="text-xl font-bold text-slate-800">SimpleBank</h1>
          <div className="flex items-center gap-4">
            <span className="text-sm text-slate-600">Hi, {account?.name ?? user?.name}</span>
            <button
              onClick={handleLogout}
              className="text-sm font-medium text-slate-500 hover:text-red-600 transition"
            >
              Sign out
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-8 grid gap-6 md:grid-cols-3">
        {/* Balance + transactions */}
        <section className="md:col-span-2 space-y-6">
          <div className="bg-white rounded-2xl shadow-sm p-6">
            <p className="text-sm text-slate-500">Available balance</p>
            <p className="text-3xl font-bold text-slate-800 mt-1">
              ${account?.balance.toFixed(2)}
            </p>
          </div>

          <div className="bg-white rounded-2xl shadow-sm p-6">
            <h2 className="text-lg font-semibold text-slate-800 mb-4">Recent transactions</h2>
            {transactions.length === 0 ? (
              <p className="text-sm text-slate-500">No transactions yet.</p>
            ) : (
              <ul className="divide-y divide-slate-100">
                {transactions.map((t) => (
                  <li key={t.id} className="py-3 flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-slate-700">{t.description}</p>
                      <p className="text-xs text-slate-400">{t.date}</p>
                    </div>
                    <span
                      className={`text-sm font-semibold ${
                        t.type === "credit" ? "text-green-600" : "text-slate-700"
                      }`}
                    >
                      {t.type === "credit" ? "+" : "-"}${t.amount.toFixed(2)}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </section>

        {/* Transfer form */}
        <section className="bg-white rounded-2xl shadow-sm p-6 h-fit">
          <h2 className="text-lg font-semibold text-slate-800 mb-4">Transfer funds</h2>
          <TransferForm onSuccess={loadData} />
        </section>
      </main>
    </div>
  );
}
