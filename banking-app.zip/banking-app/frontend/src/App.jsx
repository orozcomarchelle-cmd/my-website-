import { useState } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import Login from "./pages/Login.jsx";
import Dashboard from "./pages/Dashboard.jsx";

// A minimal client-side "route guard": if we don't have a user in
// state, bounce to /login. Note this is a UX convenience only — it
// does NOT protect data. The real security boundary is the backend's
// requireAuth middleware (see backend/middleware/auth.js), which
// checks the actual session token on every API call regardless of
// what the frontend router does.
function RequireUser({ user, children }) {
  return user ? children : <Navigate to="/login" replace />;
}

export default function App() {
  const [user, setUser] = useState(null);

  return (
    <Routes>
      <Route path="/login" element={<Login onLoggedIn={setUser} />} />
      <Route
        path="/dashboard"
        element={
          <RequireUser user={user}>
            <Dashboard user={user} onLoggedOut={() => setUser(null)} />
          </RequireUser>
        }
      />
      <Route path="*" element={<Navigate to="/login" replace />} />
    </Routes>
  );
}
